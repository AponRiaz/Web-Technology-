<?php
$filename = "WebHW.txt";  //Filename

$file = fopen($filename, "w");
$name = "Apon Riaz";
$id = "20-42905-1";

fwrite($file,"Name: .$name. /n");
fwrite($file,"ID: ".$id. "/n");

fclose($file);                                       //Close the file

$file = fopen($filename, "r");                       //open file

$file_content = fread($file, filesize($filename));

fclose($file);
?>
