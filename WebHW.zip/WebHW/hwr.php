<?php 
	session_start();
$Name = $_REQUEST['name'];
	$Email = $_REQUEST['email'];
	$Phone = $_REQUEST['phone'];
	
    
	 $Website =$_REQUEST['website'];
	 $Gender =$_REQUEST['gender'];
	 $Age=$_REQUEST['age'];
	 
	 #$fname = $_REQUEST['formname'];
	

	if ($Name == null || $Email == null ||  $Phone == null || $Website == null || $Gender == null || $Age == null ) {
		echo "invalid Information <br>";
	}else{
		$data = $Name."|".$Email."|".$Phone."|".$Website."|".$Gender."|".$Age ."\r\n";
		$file = fopen('user.txt', 'a');
		fwrite($file, $data);

			if($fname == "create"){
				header('location: hwr.php');	
			}else{
				header('location: hw.html');
			}
	
	}

