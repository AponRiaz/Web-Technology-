<!DOCTYPE html>
<html>
<head>
	<title>Product Name</title>
</head>
<body>
	<h1>Product Name</h1>
	<p>Product Description</p>
	<p>Price: $99.99</p>
	<ul>
		<li>Product Specification 1</li>
		<li>Product Specification 2</li>
		<li>Product Specification 3</li>
	</ul>
	<h2>Customer Reviews</h2>
	<p>5 stars - Great product!</p>
	<p>4 stars - Good value for the money.</p>
	<h2>Related Products</h2>
	<p>Product 1</p>
	<p>Product 2</p>
	<p>Product 3</p>
</body>
</html>
