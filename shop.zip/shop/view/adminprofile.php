<!DOCTYPE html>
<html>
<head>
    <fieldset>
	<title>Profile</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
</head>
<body>
	<div>
		<h1>Juniadul</h1>
		<div>
			<p>I checks and approve posts made by the fund recipients</p>
		</div>
		<div>
			<p>Email: islammdjuniadul@gmail.com</p>
			<p>Phone: 01720969708</p>
			<a href="https://www.behance.net/mdjuniadulislam">Website</a>
			<a href="https://www.linkedin.com/in/md-juniadul-islam-8890141a1/">LinkedIn</a>
		</div>
	</div>
    <a href ="http://localhost:8080/shop/view/adminhome.php">Go back </a>
    </fieldset>
</body>
</html>