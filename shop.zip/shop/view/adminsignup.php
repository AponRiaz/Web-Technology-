<?php

include ('../controller/register.php');


?>
<!DOCTYPE html>
<html>
<head>
    <fieldset>
	<title>Registration Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h2>Registration Form</h2>
	<form action="../controller/register.php" method="post">
		<label for="username">Username:</label>
		<input type="text" name="username" id="username" required><br><br>
		<label for="email">Email:</label>
		<input type="email" name="email" id="email" required><br><br>
		<label for="password">Password:</label>
		<input type="password" name="password" id="password" required><br><br>
		<label for="confirm_password">Confirm Password:</label>
		<input type="password" name="confirm_password" id="confirm_password" required><br><br>
		<input type="submit" value="Register">
	</form>
    <h3>Registration Done,Go back to login page<br>
    <a href="http://localhost:8080/shop/view/adminlogin.php">Login</a>
   </h3>
   </fieldset>
</body>
</html>