<html>
<head>
    <fieldset>
  <title>Contact Us</title>
  <link rel="stylesheet" type="text/css" href="style.css">
   
</head>
<body>
  
  <h1 align="center">Contact Us</h1>
  <form action="submit-form.php" method="post">
    User name:<input type="text" name="uname" placeholder="enter the first name"><br><br>
    Comment:<textarea id="Comment" name="Comment"placeholder="please put your comment here"></textarea><br><br>
    <input type="submit" value="Submit">
  </form>
  <p style="color: red;" ;">Alternatively, you can reach us at 01720969708 or email us at contact : islammdjuniadul@gmail.com</p>
  </fieldset>
</body>
</html>



