<?php



?>
<!DOCTYPE html>
<html>
<head>
	<title>Online to Online Shopping Center</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<h1>Welcome to online shopping center</h1>
	</header>
	
	<nav>
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="http://localhost:8080/shop/view/about.php">About</a></li>
			<li><a href="http://localhost:8080/shop/view/contact.php">Contact</a></li>
            <li><a href="http://localhost:8080/shop/view/adminlogin.php">Login</a></li>
            <li><a href="http://localhost:8080/shop/view/adminsignup.php">Registration</a></li>
		</ul>
	</nav>
	
	
	
	<footer>
		<p>This  is footer</p>
	</footer>
</body>
</html>
