<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <fieldset>
	<meta charset="UTF-8">
	<title>user home</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header id="main-header">

</div>
</header>

<nav id="navbar">
    <div class="container">
</div>
</nav>
    <form>
        <h1 style="text-align:center;">Welcome to Online Shopping Center</h1> 
		<hr>
        <h2>Welcome to Admin Page</h2>
		<hr>
        <h2> Hello  
        </h2>
        <table>
            <tr>
                <td> <a href="../view/adminprofile.php">
                    <h3><i>View Profile</h3></i>
                    </a></td>
            </tr>
            <tr>
                <td> <a href="../view/addbuyer.php">
                    <h3><i>Add Buyer</h3></i>
                    </a></td>
            </tr>

            <tr>
                <td> <a href="../view/addseller.php">
                    <h3><i>Add Seller</h3></i>
                    </a></td>
            </tr>

            <tr>
                <td> <a href="../view/seeproductdetails.php">
                    <h3><i>See product details</h3></i>
                    </a></td>
            </tr>
        
            <tr>
                <td> <a href="../view/adminlogout.php">
                    <h3><i>Logout</h3></i>
                    </a></td>
            </tr>


        </table>
        </fieldset>
    </form>
</body>

</html>