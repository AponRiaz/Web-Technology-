<!DOCTYPE html>
<html>
  <head>
    <fieldset>
    <title>About Us</title>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body style="font-family:'Courier'">
    <header>
      <h1 align="center">About Us</h1>
    </header>
    <h3>Here is about our Company services</h3>
    <main>
      <h3>Our Company</h3>
      <pre>
      Online shopping center is a web application program that will reduce the manual effort required of the buyer and seller.
      To keep and manage their product purchases, payments, and inventory. 
      It keeps track of every detail of the products, sales, and customers.
      The management and administration will authorize that.
      </pre>
      <h3>Our Team</h3>
      <ul>
        <li>CEO</li>
        <li>CFO</li>
        <li>Admin</li>
      </ul>
    </main>
    <footer>
      <p>Copyright © 2023 Our Company</p>
    </footer>
    </fieldset>
  </body>
</html>