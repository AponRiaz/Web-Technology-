<?php



?>
<!DOCTYPE html>
<html>
<head>
	<fieldset>
	<title>Login Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h2>Login Form</h2>
	<form action="../view/adminhome.php" method="post">
		<label for="username">Username:</label>
		<input type="text" name="username" id="username" required><br><br>
		<label for="password">Password:</label>
		<input type="password" name="password" id="password" required><br><br>
		<input type="submit" value="Login">
	</form>
    <h3>Not Regter yet? Register Here <br>
    <a href="http://localhost:8080/shop/view/adminsignup.php">Registration</a> 
   </h3>
   </fieldset>
</body>
</html>
