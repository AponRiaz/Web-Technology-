<?php 
	session_start();

	$Id = $_REQUEST['id'];
	$Password= $_REQUEST['password'];

	if ($Id == null || $Password == null) {
		echo "invalid username/password <br>";
	}else{
		$file = fopen('user.txt', 'r');
		while (!feof($file)) {
				$line = fgets($file);
				$admin = explode('|', $line);
				print_r($admin);
				echo "<br>";
				if($Id == trim($admin[1]) && $Password == trim($admin[2])){
					setcookie('status', 'true', time()+3600, '/');
					header('location: addbuyer.php');
				}
		}
		echo "invalid user!";
	}



?>
