<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = test_input($_POST["username"]);
	$email = test_input($_POST["email"]);
	$password = test_input($_POST["password"]);
	$confirm_password = test_input($_POST["confirm_password"]);

	
	if($password != $confirm_password) {
		echo "Passwords do not match";
		exit();
	}

	// Check if username and email are valid
	if(!preg_match("/^[a-zA-Z0-9_]*$/", $username)) {
		echo "Invalid username";
		exit();
	}

	if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo "Invalid email format";
		exit();
	}
    else {
        header("Location: ../view/adminlogin.php");
    }

	
}

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
?>