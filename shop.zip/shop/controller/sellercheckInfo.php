<?php 
   
    
    $Name = $_REQUEST['username'];
    $Id = $_REQUEST['id'];
    $Password = $_REQUEST['password'];
    
    
     $Phone_Number =$_REQUEST['Pnumber'];
     $Email =$_REQUEST['email'];
     $DOB=$_REQUEST['dob'];
     

    

    if ($Name == null || $Id == null ||  $Password == null || $Phone_Number == null || $Email == null || $DOB == null ) {
        echo "invalid username/password <br>";
    }else{
  

            if(true){
                header('location: ../view/adminhome.php');   
            }else{
                header('location: ../view/adminhome.php');
            }
    
    }

?>