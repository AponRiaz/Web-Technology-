<?php


if($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = test_input($_POST["username"]);
	$password = test_input($_POST["password"]);


	if($username == "admin" && $password == "password") {
		$_SESSION["username"] = $username;
		
		exit();
	} else {
		echo "Invalid username or password";
	}
}

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
?>