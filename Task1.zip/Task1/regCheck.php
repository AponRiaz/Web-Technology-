<?php 
	session_start();
    $Name = $_REQUEST['username'];
	$Id = $_REQUEST['id'];
	$Password = $_REQUEST['password'];
	$Email =$_REQUEST['email'];
	$Age =$_REQUEST['age'];
	$Gender =$_REQUEST['gender'];
	 
	 
	 #$fname = $_REQUEST['formname'];
	

	if ($Name == null || $Id == null ||  $Password == null || $Email == null || $Age == null|| $Gender == null ) {
		echo "invalid Information <br>";
	}else{
		$data = $Name."|".$Id."|".$Password."|".$Email."|".$Age."|".$Gender."\r\n";
		$file = fopen('user.txt', 'a');
		fwrite($file, $data);

			if($fname == "create"){
				header('location: home.php');	
			}else{
				header('location: login.html');
			}
	
	}



?>