<?php 
	//session_start();
	if(isset($_COOKIE['status'])){
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Task 1 Add Pic</title>
</head>
<body>
		<h1>Task 1 Add Pic</h1>
		
		
		
		<h1 align="middle"> <img src="C:\Users\Hp\OneDrive\Pictures\11.jpg" width="100" height="120"></img></h1> 
         <a href="logout.php"> logout </a><br> 
</body>
</html>

<?php } else{

	echo "invalid request";
} ?>

