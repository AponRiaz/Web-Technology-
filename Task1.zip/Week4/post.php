<html>
<body>
    Welcome <?php echo $_POST["name"]?>; <br>
    Your email address is: <?php echo $_POST["email"] ?>; <br>
    Address <?php echo $_POST["address"]; ?> <br>
    phone: <?php echo $_POST["phone"]; ?> 

</body>
</html>