<head>   
</head>
<body>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?> method= "POST">
        Name: <input type="text"name="name"><br>
        mail: <input type="text"name="email"><br>
        address: <input type="text"name="address"><br>
        phone: <input type="text"name="phone"><br>
        <input type="submit">
    </form>
    welcome <?php echo $_POST["name"]; ?> <br>
    Your email address is: <?php echo $_POST["email"]; ?> <br>
    Address <?php echo $_POST["address"]; ?> <br>
    phone: <?php echo $_POST["phone"]; ?> 

</body>
</html>