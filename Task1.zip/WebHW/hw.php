<?php 
	session_start();
$Name = $_REQUEST['username'];
	$Id = $_REQUEST['id'];
	$Password = $_REQUEST['password'];
	
    
	 $Phone_Number =$_REQUEST['Pnumber'];
	 $Email =$_REQUEST['email'];
	 $DOB=$_REQUEST['dob'];
	 
	 #$fname = $_REQUEST['formname'];
	

	if ($Name == null || $Email == null ||  $Phone == null || $Website == null || $Gender == null || $Age == null ) {
		echo "invalid Information <br>";
	}else{
		$data = $Name."|".$Email."|".$Phone."|".$Website."|".$Gender."|".$Age ."\r\n";
		$file = fopen('user.txt', 'a');
		fwrite($file, $data);

			if($fname == "create"){
				header('location: hw.php');	
			}else{
				header('location: Submit.html');
			}
	
	}

